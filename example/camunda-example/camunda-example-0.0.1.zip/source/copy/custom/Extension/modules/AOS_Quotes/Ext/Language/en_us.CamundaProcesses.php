<?php
$mod_strings = array (
  'LBL_PANEL_BUSINESS_PROCESS' => 'BUSINESS PROCESS',
  'LBL_BUSINESS_PROCESS' => 'Process',
);