<?php
$mod_strings = array (
  'LBL_PANEL_BUSINESS_PROCESS' => 'Бизнес-процесс',
  'LBL_BUSINESS_PROCESS' => 'Процесс',
);